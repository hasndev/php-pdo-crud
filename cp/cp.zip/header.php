<?php
require_once "../db.php";
require_once "check_login.php";
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="assets/style.css">
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

</head>

<body>
    <header>
        <div class="header-container">
            <img src="./img/userlogo.png" alt="Logo" class="logo">
            <p class="username"><?php echo $_SESSION['username'] ?></p>
        </div>
        <button class="sidebar-toggle" onclick="toggleSidebar()">&#9776;</button>
        <button class="dark-mode-toggle" onclick="toggleDarkMode()">&#127769;</button>
        <a href="./logout.php" class="sidebar-toggle">Logout</a>
    </header>
    <div class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <img src="./img/userlogo.png" alt="User Avatar" class="user-avatar">
            <h3>Dashboard</h3>
        </div>
        <ul class="sidebar-menu">
            <li><a href="./dashboard.php">Dashboard</a></li>
            <li><a href="./dishes_show.php">Show dishes</a></li>
            <li><a href="./dishes_add.php">Add dishe</a></li>
            <li><a href="#">Contact Message</a></li>
        </ul>
    </div>