function toggleSidebar() {
    document.getElementById("sidebar").classList.toggle("show");
}

function toggleDarkMode() {
    document.body.classList.toggle("dark-mode");
}
