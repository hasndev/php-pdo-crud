<?php
require_once "./header.php";
?>
<div class="container">
    <h1>Show Dishes</h1>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Category</th>
                <th>Price</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>1</td>
                <td>Spaghetti</td>
                <td>Pasta</td>
                <td>$12.99</td>
                <td>Available</td>
            </tr>
            <tr>
                <td>2</td>
                <td>Chicken Teriyaki</td>
                <td>Japanese</td>
                <td>$15.99</td>
                <td>Available</td>
            </tr>
            <tr>
                <td>3</td>
                <td>Steak</td>
                <td>Grill</td>
                <td>$25.99</td>
                <td>Out of Stock</td>
            </tr>
            <tr>
                <td>4</td>
                <td>Salmon</td>
                <td>Seafood</td>
                <td>$22.99</td>
                <td>Available</td>
            </tr>
        </tbody>
    </table>
</div>
<script src="assets/script.js"></script>
</body>

</html>

