<?php
require_once "./header.php";
?>
    <div class="container">
        <div class="card">
            <h2>Dashboard</h2>
            <p>Welcome to your dashboard.</p>
        </div>
    </div>
    <script src="assets/script.js"></script>
</body>

</html>